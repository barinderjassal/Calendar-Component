/**
 * Created by Barinderjit Singh on 28/12/2016
 * Description: Sample Core Calendar Module
 *
 */
define([
    'angular',
], function (angular) {
    angular.module('SampleCoreCalendar', [
        'SampleCalendarView',
        'SampleCalendarViewPopup',
        'SampleQuarterPickerView',
        'SampleQuarterPickerPopupView',
        'SampleWeekPickerView',
        'SampleWeekPickerPopupView'
    ]);
});
