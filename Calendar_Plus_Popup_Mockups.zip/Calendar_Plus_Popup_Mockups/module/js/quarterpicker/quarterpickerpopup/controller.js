/**
 * Created by Sumit Kumar Ray Singh on 15/03/17.
 * Description:
 *
 */

define([
    'angular',
    'moment',
    'module/js/quarterpicker/quarterpickerpopup/quarterpickerpopup'
], function (angular) {
    angular.module('QuarterPickerPopup')
        .controller('QuarterPickerPopupController', ['$scope', '$filter', function ($scope, $filter) {
            
        }]);
});
