/**
 * Created by Barinderjit Singh on 29/12/16.
 * Description:
 *
 */

define([
    'angular',
    'text!server/js/sample/quarterpicker/template.html',
    'server/js/sample/quarterpicker/controller'   
], function (angular, template, moment) {
    angular.module('SampleQuarterPickerView')
        .directive('sampleQuarterPickerDirective', [function () {
            return {
                restrict: 'EAC',
                template: template,
                replace: true,
                scope: false,
                controller: 'SampleQuarterPickerViewController'
            };
        }]);
});
