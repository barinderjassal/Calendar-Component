/**
 * Created by Barinderjit Singh on 28/12/2016
 * Description: Calendar Loader for different modules
 *
 */
define([
    'module/js/corecalendar',
    'module/js/calendarplus/loader',
    'module/js/calendarplus/calendarpluspopup/loader',
    'module/js/quarterpicker/loader',
    'module/js/quarterpicker/quarterpickerpopup/loader',
    'module/js/weekpicker/loader',
    'module/js/weekpicker/weekpickerpopup/loader'
], function () {});
