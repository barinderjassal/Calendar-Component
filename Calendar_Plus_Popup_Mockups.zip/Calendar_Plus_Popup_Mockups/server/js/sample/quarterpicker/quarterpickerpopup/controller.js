/**
 * Created by Barinderjit Singh on 29/12/16.
 * Description:
 *
 */

define([
    'angular',
    'moment',
    'server/js/sample/quarterpicker/quarterpickerpopup/sample'
], function (angular, moment) {
    angular.module('SampleQuarterPickerPopupView')
        .controller('SampleQuarterPickerPopupViewController', ['$scope', '$filter', function ($scope, $filter) {            
            $scope.defaultQuarterConfigNew = {
                minYear: 2012,
                maxYear: 2021,
                currentDate: new Date(),
                setDefaultQuarter: Math.floor(new Date().getMonth() / 3),
                setCurrentYear: new Date().getFullYear(),                
                /*showPicker: function(){
                },*/
                setValInput: function(val){
                   $scope.giveVal=val;
                } 
            };
            
        }]);
});
