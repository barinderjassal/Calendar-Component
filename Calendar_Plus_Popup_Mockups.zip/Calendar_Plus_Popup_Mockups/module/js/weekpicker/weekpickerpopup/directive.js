/**
 * Created by Sumit Kumar Ray Singh on 24/03/17.
 * Description:
 *
 */

define([
    'angular',
    'moment',
    'module/js/weekpicker/weekpickerpopup/controller',
    'module/js/weekpicker/weekpickerpopup/weekpickerpopup'
], function (angular, moment) {
    angular.module('WeekPickerPopup').directive('weekPickerPopup', ['$compile','$document',function ($compile,$document) {
        return {
            restrict: 'EA',
            scope: {                 
                weekPopConfig: '='
            },
            controller: 'WeekPickerPopupController',
            link: function (scope, element, attrs) {
                var popupTemplate,popupElem;
                scope.weekPopConfig.onBodyLoad = function(){
                    popupTemplate = angular.element("<div class='week-picker-popup' click-outside-week-picker='clickOutsideWeekPicker()'><week-picker week-picker-config='weekPopConfig'></week-picker></div>");
                    popupElem = $compile(popupTemplate)(scope);
                    element.after(popupElem);
                };
                scope.weekPopConfig.onBodyLoad();
                scope.weekPopConfig.showPicker = function(){
                    angular.element(element).next().toggleClass('show-picker');
                };
                
            }
        }
        
    }]).directive('clickOutsideWeekPicker', function ($document) {
            return {
                restrict: 'A',
                scope: {
                    clickOutsideWeekPicker: '&'
                },
                link: function (scope, el, attr) {
					scope.clickOutsideCalendarPicker = function () {
                     	angular.element(el).removeClass('show-picker');
                	}
                    $document.on('click', function (e){
                        if (el !== e.target && !el[0].contains(e.target) && !e.target.hasAttribute('week-picker-popup')){
							if (!e.target.hasAttribute('week-picker-popup') &&
								((e.target.parentElement == null) || 
								 e.target.parentElement.classList.contains('calender-header-inner') || 
								 e.target.parentElement.classList.contains('year-view-link') ||
								 e.target.parentElement.classList.contains('week-view-link'))) {
								// do nothing
							} else {
								scope.$apply(function () {
									scope.$eval(scope.clickOutsideCalendarPicker);
								});
							}
							
                        }
                    });
                }
            }
        });
});
    