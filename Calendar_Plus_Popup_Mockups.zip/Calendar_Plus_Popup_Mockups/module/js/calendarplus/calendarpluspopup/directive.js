/**
 * Created by Sumit Kumar Ray.
 * Description:
 *
 */

define([
    'angular',
    'moment',
    'module/js/calendarplus/calendarpluspopup/controller',
    'module/js/calendarplus/calendarpluspopup/calendarpluspopup'
], function (angular, moment) {
    angular.module('CalendarPlusPopup').directive('calendarPlusPopup', ['$compile','$document',function ($compile,$document) {
        return {
            restrict: 'A',
            scope: {
                onMonthChangePopup: '&', //callback Function  // Data can be passed as a function the & string literal
                dateFilterPopup: '&',
                eventsPopup: '=', // Data can be passed as an object using the = string literal
                dateValuePopup: '=?',
                configPopup: '=?'
            },
            controller: 'CalendarPlusPopupController',
            link: function (scope, element, attrs) {
                var popupTemplate,popupElem;
                scope.configPopup.onBodyLoad = function(){
                    popupTemplate = angular.element("<div class='calendar-picker-popup' click-outside-calendar-picker='clickOutsideCalendarPicker()'><calendar on-month-change='onMonthChangePopup' events='eventsPopup' date-filter='dateFilterPopup' date-value='dateValuePopup' config='configPopup' ></calendar></div>");
                    popupElem = $compile(popupTemplate)(scope);
                    element.after(popupElem);
                };
                scope.configPopup.onBodyLoad();
				
                scope.configPopup.showPicker = function() {
                    angular.element(element).next().toggleClass('show-picker');
                };
            }
        }
    }]).directive('clickOutsideCalendarPicker', function ($document) {
            return {
                restrict: 'A',
                scope: {
                    clickOutsideCalendarPicker: '&'
                },
                link: function (scope, el, attr) {
                    
					scope.clickOutsideCalendarPicker = function () {
                     	angular.element(el).removeClass('show-picker');
                	}
                    $document.on('click', function (e){
                        if (el !== e.target && !el[0].contains(e.target) && !e.target.hasAttribute('calendar-plus-popup')){
							if (!e.target.hasAttribute('calendar-plus-popup') &&
								((e.target.parentElement == null) || 
								 e.target.parentElement.classList.contains('calender-header-inner') || 
								 e.target.parentElement.classList.contains('year-view-link') ||
								 e.target.parentElement.classList.contains('month-view-link'))) {
								// do nothing
							} else {
								scope.$apply(function () {
									scope.$eval(scope.clickOutsideCalendarPicker);
								});
							}
							
							
                        }
                    });
                }
            }
        });
});


