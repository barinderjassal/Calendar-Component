/**
 * Created by Barinderjit Singh on 04/01/17.
 * Description:
 *
 */

define([
    'angular',
    'server/js/sample/weekpicker/weekpickerpopup/sample'
], function (angular) {
    angular.module('SampleWeekPickerPopupView')
        .controller('SampleWeekPickerPopupViewController', ['$scope', function ($scope) {
            var curntDate = new Date();
            
            $scope.sampleWeekPickerConfigNew = {
                presentDate: curntDate,
                yearsToSeeWeek: curntDate.getFullYear(),
                countWeekUptoDate: '12/31/2017',
                setWeekPop: function(val){
                   $scope.myVal=val;
                }
            };
            
            
                        
        }]);
});
