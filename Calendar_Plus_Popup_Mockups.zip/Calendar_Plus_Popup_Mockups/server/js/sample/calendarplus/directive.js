/**
 * Created by Leon Cutler on 7/10/14.
 * Description:
 *
 */

define([
    'angular',
    'text!server/js/sample/calendarplus/template.html',
    'server/js/sample/calendarplus/controller'   
], function (angular, template, moment) {
    angular.module('SampleCalendarView')
        .directive('sampleCalendarViewDirective', [function () {
            return {
                restrict: 'EAC',
                template: template,
                replace: true,
                scope: false,
                controller: 'SampleCalendarViewController'
            };
        }]);
});
