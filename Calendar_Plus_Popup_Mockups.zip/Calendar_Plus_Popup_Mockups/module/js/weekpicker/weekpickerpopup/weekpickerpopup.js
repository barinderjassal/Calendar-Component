/**
 * Created by Sumit Kumar Ray Singh on 24/03/17.
 * Description:
 *
 */

define([
    'angular'
], function (angular) {
    angular.module('WeekPickerPopup', []);
});
