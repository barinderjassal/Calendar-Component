/**
 * Created by Leon Cutler on 2/13/15.
 * Description:
 *
 */
define([
    'server/js/sample/directive'
], function () {
});