/**
 * Created by Sumit Kumar Ray.
 * Description:
 *
 */

define([
    'angular'
], function (angular) {
    angular.module('CalendarPlusPopup', []);
});
