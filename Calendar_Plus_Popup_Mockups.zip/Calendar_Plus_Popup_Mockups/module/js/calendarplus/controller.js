/**
 *
 * Created by Barinderjit Singh on 20/10/16.
 * Updated by Sumit Kumar Ray.
 * Description:
 *
 */
define([
    'angular',
    'moment',
    'module/js/calendarplus/calendarplus',
    'module/js/calendarplus/factory'
], function(angular, moment, template, factory) {
    angular.module('CalendarPlus').controller('CalendarPlusController', ['$scope', '$element', '$attrs', 'CalendarFactory', function($scope, $element, $attrs, CalendarFactory) {

        /* * setCalendar function set the calendar to passed date from sample controller if a date is passed from sample.
         * if date not passed, then it'll set to current date */
        var setCalendar = function(dateConfig) {
                var formatDateArr = ['MM/DD/YYYY',
                        'DD/MM/YYYY',
                        'DD-MM-YYYY',
                        'MM-DD-YYYY',
                        'YYYY-MM-DD',
                        'MMM Do YY',
                        'MMMM Do YYYY'
                    ],
                    flag = '',
                    sampleDate = '',
                    start = '',
                    getFormattedDate = '';

                if (!(moment(dateConfig, formatDateArr).isValid()) && (angular.isDefined(dateConfig))) {
                    alert('Please Enter date in valid format');
                    $scope.selected = CalendarFactory.removeTime(moment());
                } else {
                    getFormattedDate = moment(dateConfig, formatDateArr).format('MM/DD/YYYY');
                    flag = CalendarFactory.validateDate(getFormattedDate);
                    sampleDate = moment(new Date(getFormattedDate)); //Creating passed date to moment object to pass it to removeTime()
                    if (flag) {
                        $scope.selected = CalendarFactory.removeTime(sampleDate);
                    } else {
                        $scope.selected = CalendarFactory.removeTime(moment());
                    }
                }
                $scope.month = $scope.selected.clone();
                start = $scope.selected.clone();
                start.date(1); // make the date 1 of that particular month
                CalendarFactory.removeTime(start.day(0));
                CalendarFactory.createMonth($scope, start, $scope.month);
                $scope.dateChangeFlag = true;
            },
            /*
            	setCalendarCurrentDate function will set calendar to current date
        	*/
            setCalendarCurrentDate = function() {
                $scope.selected = CalendarFactory.removeTime(moment());
                $scope.month = $scope.selected.clone();
                var start = $scope.selected.clone();
                start.date(1); // make the date 1 of that particular month
                CalendarFactory.removeTime(start.day(0));
                CalendarFactory.createMonth($scope, start, $scope.month);
            },
           
            /*
				createYearList function creates the year range when user switch to year view.
        	*/
            createYearList = function(startPoint) {
                var listOfYears = [],
                    i;
                if (startPoint <= 1900) {
                    startPoint = 1900;
                }
                $scope.calenderConfig.startPointPrev = startPoint - 30;
                if ($scope.calenderConfig.startPointPrev <= 1900) {
                    $scope.calenderConfig.startPointPrev = 1900;
                }
                $scope.calenderConfig.startPointNext = startPoint + 30;
                $scope.calenderConfig.yearRange = startPoint + '-' + (startPoint + 29);
                for (i = startPoint; i <= (startPoint + 29); i++) {
                    listOfYears.push(i);
                }
                return listOfYears;
            };
        /*
         * Checks if date is coming from sample, then set calendar to that date, else set to current date
         */
        if (!!$scope.dateValue && $scope.dateValue !== undefined && $scope.dateValue !== null) {
			setCalendar($scope.dateValue);		
        } else {
            setCalendarCurrentDate();
        }

        /*
         * Reset the calendar on changing the view of the portlet
         */
        if (!!$scope.config && (typeof $scope.config === 'object')) {
            $scope.config.resetCalendar = function() {
                $scope.resetCalenderConfig();
                setCalendarCurrentDate();
                $scope.currentSelectedMonthIndex = moment().month();
                $scope.currentselectedYear = moment().year();
				$scope.config.setDateCal(moment().format('MM/DD/YYYY'));
            };
        }

        $scope.resetCalenderConfig = function() {
            $scope.calenderConfig.yearRange = '';
            $scope.calenderConfig.startPointPrev = 0;
            $scope.calenderConfig.startPointNext = 0;
            $scope.calenderConfig.parseInt = parseInt;
            $scope.calenderConfig.weekAndDate = 'true';
            $scope.calenderConfig.visibleViewItem = '';
            $scope.calenderConfig.currentVisibleValue = 'month';
            $scope.calenderConfig.allWeekNames = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
        };

        $scope.calenderConfig = {
            yearRange: '',
            startPointPrev: 0,
            startPointNext: 0,
            parseInt: parseInt,
            weekAndDate: 'true',
            visibleViewItem: '',
            currentVisibleValue: 'month',
            allWeekNames: ['S', 'M', 'T', 'W', 'T', 'F', 'S']
        };
        
        /* 
         * changeView function shows all the months, year-range when user clicks on current month name on calendar.
         * or when user clicks on a year on month-view.
         */
        $scope.changeView = function() {
            switch ($scope.calenderConfig.currentVisibleValue) {
                case 'month':
                    $scope.calenderConfig.visibleViewItem = 'month';
                    $scope.calenderConfig.weekAndDate = 'false';
                    $scope.allMonthsName = moment.monthsShort(); // getting all month names to show on month view
                    $scope.calenderConfig.currentVisibleValue = 'year';
                    break;

                case 'year':
                    $scope.calenderConfig.visibleViewItem = 'year';
                    $scope.allYearsName = createYearList($scope.month.year() - 5);
                    $scope.calenderConfig.currentVisibleValue = 'yearRange';
                    break;

                case 'yearRange':
                    $scope.calenderConfig.weekAndDate = 'false';
                    $scope.allMonthsName = moment.monthsShort(); // getting all month names to show on month view
                    $scope.calenderConfig.currentVisibleValue = 'yearRange';
                    break;
            }
        };

       
        $scope.currentSelectedMonthIndex = moment().month();
		
        $scope.openSelectedMonth = function(selectedMonthIndex) {
            $scope.currentSelectedMonthIndex = selectedMonthIndex;
            $scope.calenderConfig.weekAndDate = 'true';
            $scope.calenderConfig.visibleViewItem = '';
            var year = $scope.month.year(),
                getSelectedMonth = CalendarFactory.removeTime(moment().year($scope.month.year()).month(selectedMonthIndex).date(1).day(0)),
                monthObject = $scope.month.month(selectedMonthIndex);

            moment().year($scope.month.year()).month(selectedMonthIndex);
            if ($attrs.onMonthChange !== '') {
                $scope.onMonthChange({
                    monthIndex: monthObject.month() + 1,
                    monthName: $scope.month.format("MMM'YY"),
                    year: $scope.month.year()
                });
            }
            CalendarFactory.createMonth($scope, getSelectedMonth, $scope.month);

            $scope.calenderConfig.currentVisibleValue = 'month';
        };
		
        $scope.currentselectedYear = moment().year();

        $scope.showMonthsOfYear = function(selectedYear) {
            $scope.currentselectedYear = selectedYear;
            $scope.yearNameOnMonthView = true;
            $scope.month.year(selectedYear);
            $scope.calenderConfig.currentVisibleValue = 'month';
            $scope.changeView();

        };
        /*
            $scope.checkEvent() function is invoked when user hover on any date.
        */
        $scope.checkEvent = function(day) {
            /*if ($scope.events.indexOf(parseInt(day.number)) > -1)
                $scope.tooltipText = "";
             else 
                $scope.tooltipText = "No Event";
            */
        };
        
       
        /*
            $scope.select() function is invoked when any date is selected on the calendar.
        */
        $scope.select = function(day) {
            if (day.isCurrentMonth === false) {
				
				var getMonthObject = $scope.month.clone(), // current month
					onScreenMonthIndex = getMonthObject.month() + 1,
					selectedMonthIndex = day.date.month() + 1,
					onScreenYear = getMonthObject.year(),
					onSelectedYear = day.date.year();
				
				if (selectedMonthIndex < onScreenMonthIndex && onScreenYear === onSelectedYear) {
					$scope.previous();
				} else if (selectedMonthIndex > onScreenMonthIndex && onScreenYear > onSelectedYear){
					$scope.previous();
				} else if (selectedMonthIndex > onScreenMonthIndex) {
					$scope.next();
				} else if (selectedMonthIndex < onScreenMonthIndex && onScreenYear < onSelectedYear) {
					$scope.next();
				}
				
				$scope.selected = day.date;
				
            } else if ($attrs.dateFilter !== '' && day.isCurrentMonth === true) {
                $scope.dateFilter({
                    date: day.date.date(),
                    month: day.date.month() + 1,
                    year: day.date.year(),
                    day: day
                });
                $scope.selected = day.date;
                
            }
			
            $scope.config.setDateCal($scope.selected.format('MM/DD/YYYY'));
           
        };
        
        /* 
         * $scope.next function is called when arrow for next button is clicked. It builds the calendar for next month, year
         * Also, if there is any custom defined function in the invoking module, it calls that.
         */
        $scope.next = function() {
            switch ($scope.calenderConfig.currentVisibleValue) {
                case 'month':
                    var next = $scope.month.clone();
					$scope.currentSelectedMonthIndex = next.month()+1;
                    CalendarFactory.removeTime(next.month(next.month() + 1).date(1).day(0)); // on next month view, 1st date on that view
                    $scope.month.month($scope.month.month() + 1);
                    if ($attrs.onMonthChange !== '') {
                        $scope.onMonthChange({
                            monthIndex: $scope.month.month() + 1,
                            monthName: $scope.month.format("MMM'YY"),
                            year: $scope.month.year()
                        });
                    }
                    CalendarFactory.createMonth($scope, next, $scope.month);
					
                    break;

                case 'year':
                    $scope.month = moment().year($scope.month.year() + 1);
                    break;

                case 'yearRange':
                    $scope.allYearsName = createYearList($scope.calenderConfig.startPointNext);
                    break;
            }
        };

        /* 
         * $scope.previous function is called when arrow for previous button is clicked. builds the calendar for prev month,
         * year, Also, if there is any custom defined function in the invoking module, it calls that.
         */
        $scope.previous = function() {
            switch ($scope.calenderConfig.currentVisibleValue) {
                case 'month':
                    var previous = $scope.month.clone();
					$scope.currentSelectedMonthIndex = previous.month() - 1;
                    CalendarFactory.removeTime(previous.month(previous.month() - 1).date(1).day(0));
                    $scope.month.month($scope.month.month() - 1);
                    if ($attrs.onMonthChange !== '') {
                        $scope.onMonthChange({
                            monthIndex: $scope.month.month() + 1,
                            monthName: $scope.month.format("MMM'YY"),
                            year: $scope.month.year()
                        });
                    }
                    CalendarFactory.createMonth($scope, previous, $scope.month);

                    break;

                case 'year':
                    $scope.month = moment().year($scope.month.year() - 1);
                    break;

                case 'yearRange':
                    $scope.allYearsName = createYearList($scope.calenderConfig.startPointPrev);
                    break;
            }
        };
		
        $scope.selectToday = function(){
            setCalendarCurrentDate();            
            $scope.calenderConfig.visibleViewItem = '';
            $scope.calenderConfig.currentVisibleValue = 'month';
            $scope.calenderConfig.weekAndDate = 'true';
			$scope.currentSelectedMonthIndex = moment().month();
			$scope.config.setDateCal(moment().format('MM/DD/YYYY'));
       };
		
        $scope.clearDate = function(){
           $scope.config.setDateCal('');
       };
        
       /*
        * Set current date
        */
        $scope.config.setDateCal($scope.dateValue);
		
    }]);
});