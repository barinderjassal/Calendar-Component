/**
 * Created by Barinderjit Singh on 04/01/17.
 * Description:
 *
 */

define([
    'server/js/sample/weekpicker/weekpickerpopup/directive'
], function () {
});