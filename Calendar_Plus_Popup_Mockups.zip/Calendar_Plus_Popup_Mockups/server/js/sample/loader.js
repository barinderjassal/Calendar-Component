/**
 * Created by Barinderjit Singh on 28/12/2016
 * Description: Sample Core Calendar Loader
 *
 */

define([
    'server/js/sample/sample',
    'server/js/sample/calendarplus/directive',
    'server/js/sample/calendarplus/calendarpluspopup/directive',
    'server/js/sample/quarterpicker/directive',
    'server/js/sample/quarterpicker/quarterpickerpopup/directive',
    'server/js/sample/weekpicker/directive',
    'server/js/sample/weekpicker/weekpickerpopup/directive'
], function () {

});
