/**
 *
 * Created by Barinderjit Singh on 28/12/16.
 *Updated by Sumit Kumar Ray.
 */

define([
    'angular',
    'moment',
    'module/js/quarterpicker/quarterpicker'
], function(angular, moment) {
    angular.module('QuarterPicker').controller('QuarterPickerController', ['$scope', '$element', '$attrs', function($scope, $element, $attrs) {
		
        if ($scope.quarterConfig !== undefined && $scope.quarterConfig !== null && (typeof $scope.quarterConfig === 'object')) {
            $scope.yearRange = {
                minYear: $scope.quarterConfig.minYear,
                maxYear: $scope.quarterConfig.maxYear,
                quarter: ['Q1', 'Q2', 'Q3', 'Q4'],
                currentDte: $scope.quarterConfig.currentDate,
                currentQuarter: $scope.quarterConfig.setDefaultQuarter, //this is a number between 0-3
                selectedYear: $scope.quarterConfig.setCurrentYear,
                monthsName: moment.monthsShort(),

            };
			
            $scope.quarterObj = {
                "Q1": 'Jan, Feb, Mar',
                "Q2": 'Apr, May, Jun',
                "Q3": 'Jul, Aug, Sep',
                "Q4": 'Oct, Nov, Dec',
            };

        } else {
            throw 'undefined argument or mismatch variable type in Notifier Callback';
        }
        $scope.calenderConfig = {
            yearRange: '',
            startPointPrev: 0,
            startPointNext: 0,
            parseInt: parseInt,
            weekAndDate: 'true',
            visibleViewItem: 'quarter',
            currentVisibleValue: 'year'
        };

        createYearList = function(startPoint) {
            var listOfYears = [],
                i;
            if (startPoint <= 1900) {
                startPoint = 1900;
            }
            $scope.calenderConfig.startPointPrev = startPoint - 30;
            if ($scope.calenderConfig.startPointPrev <= 1900) {
                $scope.calenderConfig.startPointPrev = 1900;
            }
            $scope.calenderConfig.startPointNext = startPoint + 30;
            $scope.calenderConfig.yearRange = startPoint + '-' + (startPoint + 29);
            for (i = startPoint; i <= (startPoint + 29); i++) {
                listOfYears.push(i);
            }
            return listOfYears;
        };

        $scope.month = moment();
        $scope.changeView = function() {
            switch ($scope.calenderConfig.currentVisibleValue) {
                case 'quarter':
                    $scope.allYearsName = createYearList($scope.month.year() - 5);
                    $scope.calenderConfig.visibleViewItem = 'year';
                    $scope.calenderConfig.currentVisibleValue = 'yearRange';
                    break;
                case 'year':
                    $scope.calenderConfig.visibleViewItem = 'year';
                    $scope.allYearsName = createYearList($scope.month.year() - 5);
                    $scope.calenderConfig.currentVisibleValue = 'yearRange';
                    break;
            }
        };
        $scope.currentselectedYear = moment().year();
        $scope.showYear = function(selectedYear) {
            $scope.currentselectedYear = selectedYear;
            $scope.month.year(selectedYear);
            $scope.calenderConfig.currentVisibleValue = 'year';
            $scope.calenderConfig.visibleViewItem = 'quarter';
            $scope.quarterPickerVal = getQuarterText($scope.currentQuarterIndex)+ ',' + $scope.currentselectedYear;
        };
        $scope.currentQuarterIndex = Math.floor(new Date().getMonth() / 3);
        $scope.selectQuarter = function(currindex) {
            $scope.currentQuarterIndex = currindex;
             $scope.quarterPickerVal = getQuarterText(currindex)+ ',' + $scope.currentselectedYear;
            $scope.quarterConfig.setValInput($scope.quarterPickerVal);
        };
        
        function getQuarterText(index){
            switch(index){
                case 0:
                    return 'Q1';
                    break;
                case 1:
                    return 'Q2';
                    break;
                case 2:
                    return 'Q3';
                    break;
                case 3:
                    return 'Q4';
                    break; 
                default:
                    return 'Q?';
                    
            }
        }
        $scope.quarterPickerVal = getQuarterText($scope.currentQuarterIndex)+ ',' + $scope.currentselectedYear; 
        $scope.quarterConfig.setValInput($scope.quarterPickerVal);
		
        $scope.next = function() {
            switch ($scope.calenderConfig.currentVisibleValue) {
                case 'year':
                    $scope.month = moment().year($scope.month.year() + 1);
                    $scope.currentselectedYear = $scope.month.year();
                    break;

                case 'yearRange':
                    $scope.allYearsName = createYearList($scope.calenderConfig.startPointNext);
                    break;
            }
        };
        $scope.previous = function() {
            switch ($scope.calenderConfig.currentVisibleValue) {
                case 'year':
                    $scope.month = moment().year($scope.month.year() - 1);
                    $scope.currentselectedYear = $scope.month.year();
                    break;

                case 'yearRange':
                    $scope.allYearsName = createYearList($scope.calenderConfig.startPointPrev);
                    break;
            }
        };

    }]);
});