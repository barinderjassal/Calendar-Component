/**
 * Created by Barinderjit Singh on 04/01/17.
 * Description:
 *
 */

define([
    'angular',
    'moment',
    'module/js/weekpicker/weekpicker'
], function (angular, moment) {
    angular.module('WeekPicker').controller('WeekPickerController', ['$scope', function ($scope) {
    
        var makeDate = '',
            i,
            first,
            dayms,
            numday,
            weeks,
            date,
            week1,
            numberOfWeeksInYear,
            getIsoWeeks = function (d) {
                first = new Date(d.getFullYear(), 0, 4);
                dayms = 1000 * 60 * 60 * 24;
                numday = ((d - first) / dayms);
                weeks = Math.ceil((numday + first.getDay() + 1) / 7);
                return weeks;
            },
            dividingWeeksInQuarter = function (crYear) {
                makeDate = '12/31/' + crYear;
                numberOfWeeksInYear = getIsoWeeks(new Date(makeDate)); //get number of weeks in a year
                $scope.firstQuarterWeeksNumber = numberOfWeeksInYear > 52 ? 14 : 13;
            },
            intializeWeekPickerConfig = function (weekConfig) {
                if (weekConfig !== undefined && weekConfig !==  null && (typeof weekConfig === 'object')) {
                    $scope.weekOptions = {
                        dt: weekConfig.presentDate,
                        currentYear: weekConfig.yearsToSeeWeek,
                        futureDate: weekConfig.countWeekUptoDate,
                        yearToGetWeekNumber: weekConfig.yearsToSeeWeek,
                        previousYear: function () {
                            $scope.weekOptions.currentYear -= 1;
                            dividingWeeksInQuarter($scope.weekOptions.currentYear);
                            $scope.currentWeek = '';
                        },
                        nextYear: function () {
                            $scope.weekOptions.currentYear += 1;
                            dividingWeeksInQuarter($scope.weekOptions.currentYear);
                            $scope.currentWeek = '';
                        }
                    };
                    dividingWeeksInQuarter($scope.weekOptions.currentYear);
                } else {
                    throw 'undefined argument or mismatch variable type in Notifier Callback';
                }
        $scope.calenderWeekConfig = {
            yearRange: '',
            startPointPrev: 0,
            startPointNext: 0,
            parseInt: parseInt,
            weekAndDate: 'true',
            visibleViewItem: 'weeks',
            currentVisibleValue: 'year'
        };

        createYearFullList = function(startPoint) {
            var listOfYears = [],
                i;
            if (startPoint <= 1900) {
                startPoint = 1900;
            }
            $scope.calenderWeekConfig.startPointPrev = startPoint - 30;
            if ($scope.calenderWeekConfig.startPointPrev <= 1900) {
                $scope.calenderWeekConfig.startPointPrev = 1900;
            }
            $scope.calenderWeekConfig.startPointNext = startPoint + 30;
            $scope.calenderWeekConfig.yearRange = startPoint + '-' + (startPoint + 29);
            for (i = startPoint; i <= (startPoint + 29); i++) {
                listOfYears.push(i);
            }
            return listOfYears;
        };
        $scope.month = moment();
        $scope.changeView = function() {
            switch ($scope.calenderWeekConfig.currentVisibleValue) {
                case 'weeks':
                    $scope.allYearsName = createYearFullList($scope.month.year() - 5);
                    $scope.calenderWeekConfig.visibleViewItem = 'year';
                    $scope.calenderWeekConfig.currentVisibleValue = 'yearRange';
                    break;
                case 'year':
                    $scope.calenderWeekConfig.visibleViewItem = 'year';
                    $scope.allYearsName = createYearFullList($scope.month.year() - 5);
                    $scope.calenderWeekConfig.currentVisibleValue = 'yearRange';
                    break;
            }
        };
        $scope.currentselectedYear = moment().year();
        $scope.showYear = function(selectedYear) {
            $scope.currentselectedYear = selectedYear;
            $scope.month.year(selectedYear);
            $scope.calenderWeekConfig.currentVisibleValue = 'year';
            $scope.calenderWeekConfig.visibleViewItem = 'weeks';
        };
        $scope.next = function() {
            switch ($scope.calenderWeekConfig.currentVisibleValue) {
                case 'year':
                    $scope.month = moment().year($scope.month.year() + 1);
                    $scope.currentselectedYear = $scope.month.year();
                    break;

                case 'yearRange':
                    $scope.allYearsName = createYearFullList($scope.calenderWeekConfig.startPointNext);
                    break;
            }
        };
        $scope.previous = function() {
            switch ($scope.calenderWeekConfig.currentVisibleValue) {
                case 'year':
                    $scope.month = moment().year($scope.month.year() - 1);
                    $scope.currentselectedYear = $scope.month.year();
                    break;

                case 'yearRange':
                    $scope.allYearsName = createYearFullList($scope.calenderWeekConfig.startPointPrev);
                    break;
            }
        };
            },
            formatWeekNumber = function (weekNo) {
                return weekNo < 10 ? '0'+weekNo : weekNo; 
            };
        
        intializeWeekPickerConfig($scope.weekPickerConfig);
        
        // Returns the ISO week of the date.
        Date.prototype.getWeek = function () {
            date = new Date();
            date.setHours(0, 0, 0, 0);
          // Thursday in current week decides the year.
            date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
          // January 4 is always in week 1.
            week1 = new Date(date.getFullYear(), 0, 4);
          // Adjust to Thursday in week 1 and count number of weeks from date to week1.
            return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
           
        };
        function getFirstDateOfWeek(w, y) {
            var d = (1 + (w - 1) * 7); // 1st of January + 7 days for each week
            return new Date(y, 0, d);
        };
        function getLastDateOfWeek(w, y) {
            var d = (1 + (w - 1) * 7)+6; // 1st of January + 7 days for each week
            return new Date(y, 0, d);  
        };
        $scope.getWeekDate = function(item){
            var year = $scope.month.year();
            var MonthArray = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            var d1 = getFirstDateOfWeek(item,year);
            var d2 = getLastDateOfWeek(item,year);
            var m1 = moment(d1);
            var m2 = moment(d2);
            $scope.stDateDisp=m1.date()+" "+MonthArray[m1.month()];  
            $scope.endDateDisp=m2.date()+" "+MonthArray[m2.month()];  
        };
        
        $scope.start = 0;
        $scope.end = 53;
        $scope.items = [];
        for (i = 1; i < 54; i++) {
            $scope.items.push(i);
        }
        var getWeekNumber = $scope.weekOptions.dt.getWeek();
        $scope.currentWeek = formatWeekNumber(getWeekNumber);
        
        $scope.getCurrentWeek = function () {
            var getWeekNumber = $scope.weekOptions.dt.getWeek();
            $scope.currentWeek = formatWeekNumber(getWeekNumber);
            $scope.weekOptions.currentYear = new Date().getFullYear();
            dividingWeeksInQuarter($scope.weekOptions.currentYear);
        };
        $scope.heighlightSelectedWeek = function (selectedWeek) { 
            $scope.getWeekDate(selectedWeek);
            $scope.currentWeek = formatWeekNumber(selectedWeek);            
            $scope.getSelectedWeek = '(' + $scope.currentWeek + ') ' + $scope.stDateDisp + ' - ' + $scope.endDateDisp + ' ' + $scope.currentselectedYear;
            $scope.weekPickerConfig.setWeekPop($scope.getSelectedWeek);
        };
        $scope.heighlightSelectedWeek($scope.currentWeek);
        $scope.getSelectedWeek = '(' + $scope.currentWeek + ')' + $scope.stDateDisp + ' - ' + $scope.endDateDisp + $scope.currentselectedYear;
    
    }]).filter('slice', function () {
        return function (arr, start, end) {
            return arr.slice(start, end);
        };
    });
});