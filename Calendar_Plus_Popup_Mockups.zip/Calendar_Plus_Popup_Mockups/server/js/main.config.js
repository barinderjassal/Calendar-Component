require.config({
    baseUrl: '/',
    paths: {
        'angular': '/server/bower_components/angular/angular',
		'moment': '/server/bower_components/moment/moment',
        'domready': '/server/bower_components/requirejs-domready/domReady',
        'text': '/server/bower_components/requirejs-text/text',
        'app': '/server/js/app',
        'angularBootstrap': '/server/bower_components/angular-bootstrap/ui-bootstrap-tpls',
        'CoreCalendar': '/module/js/loader'
    },
    shim: {
        angular: {exports: 'angular'},
        moment: {exports: 'moment'},
        angularBootstrap: {
            deps: ['angular']
        },
        CoreCalendar: {
            deps: ['angular', 'moment']
        }
    }
});

require(['domready', 'angular', 'app'], function (domReady, angular) {
    domReady(function () {
        angular.bootstrap(document, ['app']);
    });
});