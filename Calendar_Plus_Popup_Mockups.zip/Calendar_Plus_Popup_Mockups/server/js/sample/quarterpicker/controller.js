/**
 * Created by Barinderjit Singh on 29/12/16.
 * Description:
 *
 */

define([
    'angular',
    'moment',
    'server/js/sample/quarterpicker/sample'
], function (angular, moment) {
    angular.module('SampleQuarterPickerView')
        .controller('SampleQuarterPickerViewController', ['$scope', '$filter', function ($scope, $filter) {
            
            $scope.defaultQuarterConfig = {
                minYear: 2012,
                maxYear: 2021,
                currentDate: new Date(),
                setDefaultQuarter: Math.floor(new Date().getMonth() / 3),
                setCurrentYear: new Date().getFullYear(),
                setValInput: function(val){
                    $scope.calVal=val;
                } 
            };
            
            
        }]);
});
