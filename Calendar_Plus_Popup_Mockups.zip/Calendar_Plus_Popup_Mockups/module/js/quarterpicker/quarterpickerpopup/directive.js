/**
 * Created by Sumit Kumar Ray Singh on 15/03/17.
 * Description:
 *
 */

define([
    'angular',
    'moment',
    'module/js/quarterpicker/quarterpickerpopup/controller',
    'module/js/quarterpicker/quarterpickerpopup/quarterpickerpopup'
], function (angular, moment) {
    angular.module('QuarterPickerPopup').directive('quarterPickerPopup', ['$compile','$document',function ($compile,$document) {
        return {
            restrict: 'EA',
            scope: {
                quarterPopConfig:'='
            },
            controller: 'QuarterPickerPopupController',
            link: function (scope, element, attrs) {
                var popupTemplate,popupElem;
                scope.quarterPopConfig.onBodyLoad = function(){
                    popupTemplate = angular.element("<div class='quarter-picker-popup' click-outside-quarter-picker='clickOutsideQuarterPicker()'><quarter-picker quarter-config='quarterPopConfig'></quarter-picker></div>");
                    popupElem = $compile(popupTemplate)(scope);
                    element.after(popupElem);
                };
                scope.quarterPopConfig.onBodyLoad();
                scope.quarterPopConfig.showPicker = function(){
                    angular.element(element).next().toggleClass('show-picker');
                };
                
            }
        }
    }]).directive('clickOutsideQuarterPicker', function ($document) {
            return {
                restrict: 'A',
                scope: {
                    clickOutsideQuarterPicker: '&'
                },
                link: function (scope, el, attr) {
                    
					scope.clickOutsideCalendarPicker = function () {
                     	angular.element(el).removeClass('show-picker');
                	}
                    $document.on('click', function (e){
                        if (el !== e.target && !el[0].contains(e.target) && !e.target.hasAttribute('quarter-picker-popup')){
							if (!e.target.hasAttribute('quarter-picker-popup') &&
								((e.target.parentElement == null) || 
								 e.target.parentElement.classList.contains('calender-header-inner') || 
								 e.target.parentElement.classList.contains('year-view-link') ||
								 e.target.parentElement.classList.contains('quarter-view-link'))) {
								// do nothing
							} else {
								scope.$apply(function () {
									scope.$eval(scope.clickOutsideCalendarPicker);
								});
							}
							
							
                        }
                    });
                }
            }
        });
});