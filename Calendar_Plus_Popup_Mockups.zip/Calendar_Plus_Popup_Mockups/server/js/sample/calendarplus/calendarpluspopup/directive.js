/**
 * Created by Leon Cutler on 7/10/14.
 * Description:
 *
 */

define([
    'angular',
    'text!server/js/sample/calendarplus/calendarpluspopup/template.html',
    'server/js/sample/calendarplus/calendarpluspopup/controller'   
], function (angular, template, moment) {
    angular.module('SampleCalendarViewPopup')
        .directive('sampleCalendarViewPopupDirective', [function () {
            return {
                restrict: 'EAC',
                template: template,
                replace: true,
                scope: true,
                controller: 'SampleCalendarViewPopupController'
            };
        }]);
});
