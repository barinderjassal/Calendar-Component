/**
 * Created by Barinderjit Singh on 29/12/16.
 * Description:
 *
 */

define([
    'angular',
    'text!server/js/sample/quarterpicker/quarterpickerpopup/template.html',
    'server/js/sample/quarterpicker/quarterpickerpopup/controller'   
], function (angular, template, moment) {
    angular.module('SampleQuarterPickerPopupView')
        .directive('sampleQuarterPickerPopupDirective', [function () {
            return {
                restrict: 'EAC',
                template: template,
                replace: true,
                scope: false,
                controller: 'SampleQuarterPickerPopupViewController'
            };
        }]);
});
