/**
 * Created by Barinderjit Singh on 29/12/16.
 * Description:
 *
 */
define([
    'server/js/sample/quarterpicker/directive'
], function () {
});