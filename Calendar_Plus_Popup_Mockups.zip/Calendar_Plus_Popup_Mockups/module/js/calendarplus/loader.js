/**
 *
 * Created by Barinderjit Singh on 20/10/16.
 * Updated by Sumit Kumar Ray.
 * Description:
 *
 */
define([
    'module/js/calendarplus/directive'
], function () {
});