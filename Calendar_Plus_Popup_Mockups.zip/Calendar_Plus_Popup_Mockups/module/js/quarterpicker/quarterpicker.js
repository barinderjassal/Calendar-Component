/**
 * Created by Barinderjit Singh on 28/12/16.
 * Description:
 *
 */

define([
    'angular'
], function (angular) {
    angular.module('QuarterPicker', []);
});
