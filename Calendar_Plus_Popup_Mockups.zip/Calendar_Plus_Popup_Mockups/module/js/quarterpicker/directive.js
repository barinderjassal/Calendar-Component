/**
 * 
 * Created by Barinderjit Singh on 28/12/16.
 * Description:
 *
 */

define([
    'angular',
    'moment',
    'text!module/js/quarterpicker/template.html',
    'module/js/quarterpicker/controller',
    'module/js/quarterpicker/quarterpicker'
], function (angular, moment, template) {
    angular.module('QuarterPicker').directive('quarterPicker', [function () {
        return {
            restrict: 'EA',
            template: template,
            require: '?ngModel',
            scope: {
                quarterConfig: '='  
            },
            controller: 'QuarterPickerController',
            link: function (scope, element, attrs, ngModel) {
                scope.quarterConfig.hidePicker = function(){
                   angular.element(element).parent().removeClass('show-picker');
                };
            }
        }
    }]);
});