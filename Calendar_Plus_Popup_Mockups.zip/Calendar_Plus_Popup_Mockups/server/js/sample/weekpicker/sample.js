/**
 * Created by Barinderjit Singh on 04/01/17.
 * Description:
 *
 */

define([
    'angular'
], function (angular) {
    angular.module('SampleWeekPickerView', []);
});