/**
 * Created by Barinderjit Singh on 28/12/2016
 * Description:
 *
 */
define([
    'angular'
], function (angular) {
    angular.module('SampleQuarterPickerPopupView', []);
});