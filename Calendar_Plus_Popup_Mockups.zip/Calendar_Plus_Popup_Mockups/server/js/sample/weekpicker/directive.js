/**
 * Created by Barinderjit Singh on 04/01/17.
 * Description:
 *
 */

define([
    'angular',
    'text!server/js/sample/weekpicker/template.html',
    'server/js/sample/weekpicker/controller'   
], function (angular, template, moment) {
    angular.module('SampleWeekPickerView')
        .directive('sampleWeekPickerDirective', [function () {
            return {
                restrict: 'EA',
                template: template,
                replace: true,
                scope: false,
                controller: 'SampleWeekPickerViewController'
            };
        }]);
});
