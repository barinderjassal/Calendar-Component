/**
 * Created by Barinderjit Singh on 04/01/17.
 * Description:
 *
 */

define([
    'angular',
    'moment',
    'text!module/js/weekpicker/template.html',
    'module/js/weekpicker/controller',
    'module/js/weekpicker/weekpicker'
], function (angular, moment, template) {
    angular.module('WeekPicker').directive('weekPicker', [function () {
        return {
            restrict: 'EA',
            template: template,
            scope: {
                weekPickerConfig: '='
            },
            controller: 'WeekPickerController',
            link: function (scope, element, attrs) {
                scope.weekPickerConfig.hidePicker = function(){
                   angular.element(element).parent().removeClass('show-picker');
                };
            }
        }
        
    }]);
});
    