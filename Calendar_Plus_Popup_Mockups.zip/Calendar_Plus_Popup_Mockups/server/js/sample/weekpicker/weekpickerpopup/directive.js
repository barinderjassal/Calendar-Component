/**
 * Created by Barinderjit Singh on 04/01/17.
 * Description:
 *
 */

define([
    'angular',
    'text!server/js/sample/weekpicker/weekpickerpopup/template.html',
    'server/js/sample/weekpicker/weekpickerpopup/controller'   
], function (angular, template, moment) {
    angular.module('SampleWeekPickerPopupView')
        .directive('sampleWeekPickerPopupDirective', [function () {
            return {
                restrict: 'EA',
                template: template,
                replace: true,
                scope: false,
                controller: 'SampleWeekPickerPopupViewController'
            };
        }]);
});
