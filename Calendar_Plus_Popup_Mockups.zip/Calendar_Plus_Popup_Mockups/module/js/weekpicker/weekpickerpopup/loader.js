/**
 * Created by Sumit Kumar Ray Singh on 24/03/17.
 * Description:
 *
 */

define([
    'module/js/weekpicker/weekpickerpopup/directive'
], function () {
});