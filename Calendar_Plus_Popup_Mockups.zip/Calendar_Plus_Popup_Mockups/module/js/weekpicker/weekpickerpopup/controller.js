/**
 * Created by Sumit Kumar Ray Singh on 24/03/17.
 * Description:
 *
 */

define([
    'angular',
    'moment',
    'module/js/weekpicker/weekpickerpopup/weekpickerpopup'
], function (angular, moment) {
    angular.module('WeekPickerPopup').controller('WeekPickerPopupController', ['$scope', function ($scope) {
    
    }])
});